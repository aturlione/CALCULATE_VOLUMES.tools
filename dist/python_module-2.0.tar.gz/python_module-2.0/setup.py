from setuptools import setup

setup (

    name="python_module",
    version="2.0",
    author="Anabela Turlione",
    packages=["python_module"]

    )