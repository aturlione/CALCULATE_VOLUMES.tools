from setuptools import setup

setup (

    name="python_module",
    version="3.0",
    author="Anabela Turlione",
    packages=["python_module"]

    )